# Copyright 2024-2026 Workday, Inc. Licensed under the Apache 2.0 http://www.apache.org/licenses/LICENSE-2.0

"""Main connector module for Workday Live Data Query (LDQ)."""

from __future__ import annotations

from pathlib import Path
from typing import Dict, Union

import trino

from ._version import __version__
from .config import LDQConfig

CreateConnectionArg = Union[LDQConfig, Dict[str, str], str, Path]


def create_connection(config: CreateConnectionArg):
    """Create a Workday Live Data Query (LDQ) connection.

    The authentication flow is selected via `wd.authn.authModel` (JWT_BEARER or AUTHORIZATION_CODE).
    `config` may be:
      - a config object (`LDQConfig`)
      - a dict of properties
      - a path to a .properties file
    """
    effective_config: LDQConfig
    if isinstance(config, LDQConfig):
        effective_config = config
    elif isinstance(config, dict):
        effective_config = LDQConfig(config)
    else:
        effective_config = LDQConfig.from_file(str(config))

    auth = effective_config.create_authentication()

    return trino.dbapi.connect(
        host=effective_config.host,
        port=effective_config.port,
        catalog=effective_config.catalog,
        schema=effective_config.schema,
        http_scheme="https",
        auth=auth,
        source=f"ldq-python-client:{__version__}",
    )
