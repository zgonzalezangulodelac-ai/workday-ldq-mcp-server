# Copyright 2024-2026 Workday, Inc. Licensed under the Apache 2.0 http://www.apache.org/licenses/LICENSE-2.0

"""Constants for Workday Live Data Query (LDQ) OAuth authentication.

This module contains OAuth 2.0 string constants used across the authentication modules.
All constants follow RFC 6749 (OAuth 2.0) and RFC 7519 (JWT) specifications.
"""
from __future__ import annotations


# ---------------------------------------------------------------------------
# HTTP Headers
# ---------------------------------------------------------------------------


class HTTPHeader:
    AUTHORIZATION = "Authorization"
    CONTENT_TYPE = "Content-Type"
    TENANT = "X-Tenant"
    ACCEPT = "Accept"


# ---------------------------------------------------------------------------
# OAuth 2.0 Grant Types (RFC 6749)
# ---------------------------------------------------------------------------


class GrantType:
    AUTHORIZATION_CODE = "authorization_code"
    REFRESH_TOKEN = "refresh_token"
    JWT_BEARER = "urn:ietf:params:oauth:grant-type:jwt-bearer"


# ---------------------------------------------------------------------------
# OAuth 2.0 Token Endpoint Parameters (RFC 6749 §5.1)
# ---------------------------------------------------------------------------


class TokenRequestParam:
    GRANT_TYPE = "grant_type"
    CODE = "code"
    REDIRECT_URI = "redirect_uri"
    CLIENT_ID = "client_id"
    CLIENT_SECRET = "client_secret"
    REFRESH_TOKEN = "refresh_token"
    ASSERTION = "assertion"
    CODE_VERIFIER = "code_verifier"  # RFC 7636 (PKCE)


class TokenParam:
    ACCESS_TOKEN = "access_token"
    EXPIRES_IN = "expires_in"
    REFRESH_TOKEN = "refresh_token"
    ERROR = "error"
    ERROR_DESCRIPTION = "error_description"


# ---------------------------------------------------------------------------
# OAuth 2.0 Authorization Endpoint Parameters (RFC 6749 §4.1.1)
# ---------------------------------------------------------------------------


class AuthzParam:
    RESPONSE_TYPE = "response_type"
    CLIENT_ID = "client_id"
    REDIRECT_URI = "redirect_uri"
    STATE = "state"
    CODE = "code"
    CODE_CHALLENGE = "code_challenge"  # RFC 7636 (PKCE)
    CODE_CHALLENGE_METHOD = "code_challenge_method"  # RFC 7636 (PKCE)


class AuthzResponseType:
    CODE = "code"


# ---------------------------------------------------------------------------
# PKCE Implementation Constants (RFC 7636)
# ---------------------------------------------------------------------------

PKCE_CODE_VERIFIER_BYTE_LENGTH = 64  # 64 bytes = 86 base64url chars (matches Java)
PKCE_CODE_CHALLENGE_METHOD = "S256"  # SHA-256 hash method

# ---------------------------------------------------------------------------
# OAuth Token Endpoint Headers
# ---------------------------------------------------------------------------

OAUTH_TOKEN_ENDPOINT_HEADERS = {
    HTTPHeader.CONTENT_TYPE: "application/x-www-form-urlencoded",
    HTTPHeader.ACCEPT: "application/json",
}


# ---------------------------------------------------------------------------
# JWT Constants (RFC 7519)
# ---------------------------------------------------------------------------


class JWTHeader:
    ALG = "alg"  # Algorithm
    TYP = "typ"  # Type


class JWTAlgorithm:
    RS256 = "RS256"  # RSA Signature with SHA-256


class JWTClaim:
    # Standard claims (RFC 7519)
    ISS = "iss"  # Issuer
    SUB = "sub"  # Subject
    AUD = "aud"  # Audience
    IAT = "iat"  # Issued At
    EXP = "exp"  # Expiration Time
    JTI = "jti"  # JWT ID
    # Workday-specific
    TENANT = "tenant"  # Tenant identification


class JWTType:
    JWT = "JWT"


# ---------------------------------------------------------------------------
# Token Timing Constants
# ---------------------------------------------------------------------------

# Early refresh buffer (seconds) - refresh token this many seconds before expiration
DEFAULT_EARLY_REFRESH_SKEW_SECONDS = 300  # 5 minutes

# Default token expiration when server doesn't provide expires_in
DEFAULT_TOKEN_EXPIRATION_SECONDS = 3600  # 1 hour

# ---------------------------------------------------------------------------
# HTTP Request Timeouts
# ---------------------------------------------------------------------------

# Default timeout for OAuth token requests (seconds)
DEFAULT_HTTP_REQUEST_TIMEOUT_SECONDS = 30

# ---------------------------------------------------------------------------
# Path Prefix Constants
# ---------------------------------------------------------------------------

LDQ_GATEWAY_PATH_PREFIX = "/dataservice"

HTTPS_SCHEME = "https://"
